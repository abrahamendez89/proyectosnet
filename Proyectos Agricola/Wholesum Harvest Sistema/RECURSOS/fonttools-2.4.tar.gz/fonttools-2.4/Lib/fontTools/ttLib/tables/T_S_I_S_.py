import asciiTable

class table_T_S_I_S_(asciiTable.asciiTable):
	pass

