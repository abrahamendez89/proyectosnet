var searchData=
[
  ['x509certificate',['X509Certificate',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1JsonWebSignature_1_1Header.html#a771d60e2b7d818dc3c2f484dda142e3b',1,'Google::Apis::Auth::JsonWebSignature::Header']]],
  ['x509thumbprint',['X509Thumbprint',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1JsonWebSignature_1_1Header.html#ade56b0c3eade9808ad0136231bf3afe6',1,'Google::Apis::Auth::JsonWebSignature::Header']]],
  ['x509url',['X509Url',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1JsonWebSignature_1_1Header.html#a0ee3eabbc2048bafe94612c30badb64f',1,'Google::Apis::Auth::JsonWebSignature::Header']]]
];
