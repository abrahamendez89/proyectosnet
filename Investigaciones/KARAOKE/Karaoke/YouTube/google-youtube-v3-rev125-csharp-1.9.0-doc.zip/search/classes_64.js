var searchData=
[
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1LiveBroadcastsResource_1_1DeleteRequest.html',1,'Google::Apis::YouTube::v3::LiveBroadcastsResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1ChannelSectionsResource_1_1DeleteRequest.html',1,'Google::Apis::YouTube::v3::ChannelSectionsResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1VideosResource_1_1DeleteRequest.html',1,'Google::Apis::YouTube::v3::VideosResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1SubscriptionsResource_1_1DeleteRequest.html',1,'Google::Apis::YouTube::v3::SubscriptionsResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1PlaylistsResource_1_1DeleteRequest.html',1,'Google::Apis::YouTube::v3::PlaylistsResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1PlaylistItemsResource_1_1DeleteRequest.html',1,'Google::Apis::YouTube::v3::PlaylistItemsResource']]],
  ['deleterequest',['DeleteRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1LiveStreamsResource_1_1DeleteRequest.html',1,'Google::Apis::YouTube::v3::LiveStreamsResource']]]
];
