var searchData=
[
  ['unsetrequest',['UnsetRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1WatermarksResource_1_1UnsetRequest.html',1,'Google::Apis::YouTube::v3::WatermarksResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1ChannelSectionsResource_1_1UpdateRequest.html',1,'Google::Apis::YouTube::v3::ChannelSectionsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1PlaylistsResource_1_1UpdateRequest.html',1,'Google::Apis::YouTube::v3::PlaylistsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1PlaylistItemsResource_1_1UpdateRequest.html',1,'Google::Apis::YouTube::v3::PlaylistItemsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1ChannelsResource_1_1UpdateRequest.html',1,'Google::Apis::YouTube::v3::ChannelsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1LiveStreamsResource_1_1UpdateRequest.html',1,'Google::Apis::YouTube::v3::LiveStreamsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1VideosResource_1_1UpdateRequest.html',1,'Google::Apis::YouTube::v3::VideosResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1YouTube_1_1v3_1_1LiveBroadcastsResource_1_1UpdateRequest.html',1,'Google::Apis::YouTube::v3::LiveBroadcastsResource']]],
  ['usercredential',['UserCredential',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1OAuth2_1_1UserCredential.html',1,'Google::Apis::Auth::OAuth2']]]
];
